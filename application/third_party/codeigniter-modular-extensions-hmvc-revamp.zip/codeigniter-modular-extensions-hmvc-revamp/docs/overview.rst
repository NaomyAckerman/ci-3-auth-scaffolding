.. The overview file describes the purpose of the library
   Added: <date>
   Author: Name <email>

========
Overview
========

My Class
========

Description of the library or whatnot goes here.

These paragraphs are just regular prose, like what you'd see in any API documentation.

Quickstart
~~~~~~~~~~

Install via Composer::

    composer require swader/myawesomelib

Some other instructions go here::

    $awesome = new Awesome('param');
    $awesome->doGreatThings();
