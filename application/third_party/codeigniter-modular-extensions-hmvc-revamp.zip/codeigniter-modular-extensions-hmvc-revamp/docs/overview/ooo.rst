===================
Order of Operations
===================

The order a controller loads the model, core libraries, helpers, and any other resources is **important**.
	
Priorities
----------
#. Module
#. Application
#. System

That
----