==============
MX/Modules.php
==============

.. warning::
	The class reference below uses ``tk.phpautodoc`` to automatically generate the content.  It uses the ``phpDocumentor`` format.  Some ``DocBlock`` tags *may not* be supported, formatting *may not* render properly, content *may not* be missing, or content *may not* load at all.

Class Reference
===============



.. phpautomodule::
	:filename: ../third_party/MX/Modules.php
	:members:
	:undoc-members:



