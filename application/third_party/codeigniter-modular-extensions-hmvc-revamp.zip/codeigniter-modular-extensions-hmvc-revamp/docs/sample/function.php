<?php
/**
  * @author My Name
  * @author My Name <my.name@example.com>
  */

class somethingNew {
  
 /**
  * A summary informing the user what the associated element does.
  *
  * A *description*, that can span multiple lines, to go _in-depth_ into the details of this element
  * and to provide some background information or textual references.
  *
  * @param string $myArgument With a *description* of this argument, these may also
  *    span multiple lines.
  *
  * @return void
  */
  function myFunction($myArgument)
  {
  }
  
/**
 * A summary informing the user what the associated element does.
 *
 * A *description*, that can span multiple lines, to go _in-depth_ 
 * into the details of this element and to provide some background 
 * information or textual references.
 *
 * @author My Name
 *
 * @author My Name <my.name@example.com>
 *
 * @param string $myArgument With a *description* of this argument, 
 *
 * @return void
 */
 function anotherFunction($myArgument) {
 
 	// This is a line
 	$foo = 22;
 
 }
 
}

class anotherClass {

	/**
	  * 
	  *
	  * @return voice
	  */
	function one() {
	}

}
