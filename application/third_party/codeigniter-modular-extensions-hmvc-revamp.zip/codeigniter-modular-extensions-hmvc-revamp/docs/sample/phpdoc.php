 <?php
 /**
  * This method will not change until a major release.
  *
  * @api
  *
  * @return void
  */
  function showVersion()
  {
     //<...>
  }

 /**
  * @author My Name
  * @author My Name <my.name@example.com>
  */
	function two() {}
  
 /**
  * Page-Level DocBlock
  *
  * @category MyCategory
  * @package  MyPackage
  */
  function three() {}
  
 /**
  * @copyright 1997-2005 The PHP Group
  */
	function four() {}

/**
  * @deprecated
  * @deprecated 1.0.0
  * @deprecated No longer used by internal code and not recommended.
  * @deprecated 1.0.0 No longer used by internal code and not recommended.
  */
 function count()
 {
     //<...>
 }
 
 /**
  * @example example1.php Counting in action.
  * @example http://example.com/example2.phps Counting in action by a 3rd party.
  * @example "My Own Example.php" My counting.
  */
 function countb()
 {
     //<...>
 }
 
  /**
  * @filesource
  */
  function five() {}