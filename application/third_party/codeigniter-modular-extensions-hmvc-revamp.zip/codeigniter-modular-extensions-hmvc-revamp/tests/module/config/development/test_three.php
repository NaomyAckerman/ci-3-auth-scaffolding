<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/* vim: set expandtab tabstop=4 shiftwidth=4 encoding=utf-8: */

$config['echo']	        =	'mod::development';
$config['delta']	    =	'mod::development';

